#!/bin/bash

#change between false and true - to mute / unmute
mute=false

file=/home/dao03/Desktop/reminder.txt
cmd=${1:-'run'}
minutes=1


run(){
local line=$(random_line $file)
notify-send "$line" & 
echo "$line" | flite -voice slt &
sleep 1
echo "$line" | flite -voice kal &
sleep 1
echo "$line" | flite -voice awb &
}


random_line(){
local file=$1
local line=$(shuf -n 1 $file)
echo "$line"
}

install(){

local file_tmp=/tmp/crontab.txt
echo -e "DISPLAY=:0 \n */$minutes * * * * bash -c /home/dao03/Desktop/reminder.sh" > $file_tmp
crontab $file_tmp
sudo service cron restart
}


eval $cmd

