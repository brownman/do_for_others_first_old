# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Todo::Application.config.secret_token = '358f58a7287f2e8166595e39d324a97a66a4ce9ab0725d7430ae6524d4b9bc4777389c1a3cb2486016fbdca5d7daad16c6da2076ace35e7fda4d4850da710f4b'
