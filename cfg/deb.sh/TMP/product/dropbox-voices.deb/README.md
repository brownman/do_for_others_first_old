working together on randomly generated ideas
