__author__ = 'Marcin Kulik'
__version__ = '0.9.8'
